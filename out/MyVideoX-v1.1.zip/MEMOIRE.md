# MyVideoX (Android) — fichier de reprise
Cedric : ne connaît pas le développement, Android Studio seulement, tout se fait depuis smartphone Android (pas de PC Windows). Guider pas à pas en français simple.
But : appli autonome qui s'ouvre directement sur le dossier réseau du NAS (ASCED 192.168.1.100, SMB 445) pour lire photos/vidéos/musique ; roue crantée + code d'accès pour régler le chemin. Étape 2 : la tuile « The VidéosX » du site MyX (Netlify) ouvre l'appli (lien intent:// myvideox://open, filtre déjà dans le manifest, aucun paramètre lu).
Techno : Kotlin natif, minSdk 28, jcifs-ng 2.1.10 (même connexion que MyNASx), media3 ExoPlayer 1.2.1 + SmbDataSource (lecture en continu avec avance rapide), package com.cedric.myvideox.
Confidentialité : LAN seulement, pas de VPN, mot de passe chiffré (Keystore), code PBKDF2, FLAG_SECURE réglable.
État : v1 écrite mais NON compilée/testée (pas de SDK Android côté assistant). Prochaines étapes : retours de compilation/test, puis tuile du site.
v1.1 : écran maintenu allumé pendant la lecture vidéo (FLAG_KEEP_SCREEN_ON dans PlayerActivity).
