package com.cedric.myvideox

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.WindowManager
import android.widget.EditText

/** Dernier moment où l'appli a été utilisée (pour ne pas redemander le code à chaque écran). */
object Lock {
    @Volatile var last = 0L
    const val GRACE_MS = 60_000L
    fun touch() { last = System.currentTimeMillis() }
}

/**
 * Détecte le passage de l'appli au premier plan / arrière-plan (et non simplement le
 * passage d'un écran à l'autre à l'intérieur de l'appli) pour journaliser une vraie
 * « session » : ouverture de l'appli → fermeture de l'appli.
 */
object AppVisibility {
    private var count = 0
    private val handler = Handler(Looper.getMainLooper())
    private var closeRunnable: Runnable? = null
    @Volatile private var sessionActive = false

    fun onActivityStarted(ctx: Context) {
        count++
        closeRunnable?.let { handler.removeCallbacks(it) }
        closeRunnable = null
        if (count == 1) tryOpen(ctx)
    }

    fun onActivityStopped(ctx: Context) {
        count = (count - 1).coerceAtLeast(0)
        if (count == 0) {
            val r = Runnable { if (count == 0) closeSession(ctx) }
            closeRunnable = r
            handler.postDelayed(r, 1500)
        }
    }

    /** À rappeler juste après que le consentement a été donné (il peut manquer au premier onStart). */
    fun tryOpen(ctx: Context) {
        if (sessionActive) return
        if (!Store.hasConsent(ctx)) return
        val c = NasClient.config(ctx) ?: return
        sessionActive = true
        Journal.sessionOpen(ctx.applicationContext, c)
    }

    private fun closeSession(ctx: Context) {
        if (!sessionActive) return
        sessionActive = false
        Journal.sessionClose(ctx.applicationContext)
    }
}

/** Fenêtre de saisie du code d'accès. 5 erreurs : on ferme. */
object PinGate {
    fun ask(a: Activity, title: String, onOk: () -> Unit, onCancel: () -> Unit) {
        if (a.isFinishing) return
        var tries = 0
        val et = EditText(a).apply {
            hint = "Code d'accès"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        val d = AlertDialog.Builder(a)
            .setTitle(title)
            .setView(et)
            .setCancelable(false)
            .setPositiveButton("Valider", null)
            .setNegativeButton("Annuler") { _, _ -> onCancel() }
            .create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (Store.checkPin(a, et.text.toString())) {
                    d.dismiss()
                    onOk()
                } else {
                    et.setText("")
                    tries++
                    if (tries >= 5) {
                        d.dismiss()
                        onCancel()
                    } else et.error = "Code incorrect ($tries/5)"
                }
            }
        }
        d.show()
    }
}

abstract class BaseActivity : Activity() {
    protected var locking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Store.settings(this).secure) {
            window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    override fun onPause() {
        super.onPause()
        if (!locking) Lock.touch()
    }

    override fun onStart() {
        super.onStart()
        AppVisibility.onActivityStarted(this)
    }

    override fun onStop() {
        super.onStop()
        AppVisibility.onActivityStopped(this)
    }
}
