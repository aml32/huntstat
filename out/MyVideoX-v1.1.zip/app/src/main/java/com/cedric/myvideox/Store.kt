package com.cedric.myvideox

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Réglages de l'appli (tout est mémorisé sur le téléphone, mot de passe chiffré). */
data class Settings(
    val path: String,          // chemin réseau, ex : \\192.168.1.100\Video\Famille
    val port: Int,
    val user: String,
    val password: String,
    val strict: Boolean,       // SMB 3 + signature obligatoires
    val localOnly: Boolean,    // Wi-Fi de la maison uniquement
    val secure: Boolean,       // écran masqué dans les captures / applis récentes
    val lockOnOpen: Boolean    // demander le code aussi à l'ouverture de l'appli
)

object Store {
    private fun p(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("myvideox", Context.MODE_PRIVATE)

    fun settings(ctx: Context): Settings {
        val s = p(ctx)
        return Settings(
            path = Crypto.dec(s.getString("path", "") ?: ""),
            port = s.getInt("port", 445),
            user = Crypto.dec(s.getString("user", "") ?: ""),
            password = Crypto.dec(s.getString("pwd", "") ?: ""),
            strict = s.getBoolean("strict", true),
            localOnly = s.getBoolean("localOnly", true),
            secure = s.getBoolean("secure", true),
            lockOnOpen = s.getBoolean("lockOnOpen", false)
        )
    }

    fun save(ctx: Context, a: Settings) {
        p(ctx).edit()
            .putString("path", Crypto.enc(a.path.trim()))
            .putInt("port", a.port)
            .putString("user", Crypto.enc(a.user.trim()))
            .putString("pwd", Crypto.enc(a.password))
            .putBoolean("strict", a.strict)
            .putBoolean("localOnly", a.localOnly)
            .putBoolean("secure", a.secure)
            .putBoolean("lockOnOpen", a.lockOnOpen)
            .putLong("stamp", System.currentTimeMillis())
            .apply()
    }

    /** Efface toutes les données de l'appli (après 5 codes faux : protection anti-vol). */
    fun wipe(ctx: Context) {
        p(ctx).edit().clear().apply()
    }

    /** Change à chaque enregistrement des réglages : l'écran principal se recharge alors tout seul. */
    fun stamp(ctx: Context): Long = p(ctx).getLong("stamp", 0L)

    // ---------- Code d'accès (jamais stocké en clair : sel + PBKDF2) ----------
    private fun hash(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 60_000, 256)
        val h = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return Base64.encodeToString(h, Base64.NO_WRAP)
    }

    fun hasPin(ctx: Context): Boolean = p(ctx).getString("pinH", null) != null

    fun setPin(ctx: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p(ctx).edit()
            .putString("pinS", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pinH", hash(pin, salt)).apply()
    }

    fun checkPin(ctx: Context, pin: String): Boolean {
        val h = p(ctx).getString("pinH", null) ?: return true
        val salt = Base64.decode(p(ctx).getString("pinS", "") ?: "", Base64.NO_WRAP)
        return hash(pin, salt) == h
    }

    // ---------- Consentement « consultations enregistrées » (demandé une seule fois, pour toujours) ----------
    fun hasConsent(ctx: Context): Boolean = p(ctx).getBoolean("consent", false)
    fun setConsent(ctx: Context) {
        p(ctx).edit().putBoolean("consent", true).apply()
    }

    // ---------- Compteur de visites : incrémenté à chaque connexion à l'appli ----------
    @Synchronized
    fun nextVisitNumber(ctx: Context): Int {
        val n = p(ctx).getInt("visitNo", 0) + 1
        p(ctx).edit().putInt("visitNo", n).apply()
        return n
    }
}
