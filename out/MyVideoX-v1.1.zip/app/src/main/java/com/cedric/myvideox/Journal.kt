package com.cedric.myvideox

import android.content.Context
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Deux niveaux séparés, volontairement :
 *  1) Journal détaillé (noms de vidéos compris) : écrit UNIQUEMENT dans un
 *     dossier caché sur le NAS, jamais envoyé sur Internet.
 *  2) Résumé Telegram, volontairement léger : connexion / déconnexion,
 *     dossier(s) consulté(s) et durée — jamais le nom d'une vidéo.
 */
object Journal {

    // Même bot que le site MyX.
    private const val TELEGRAM_TOKEN = "8287408713:AAFnPmgpKgN9Ih__cNciJY8_4LSw2ABICUI"
    private const val TELEGRAM_CHAT_ID = "6483970521"

    private fun now(): String =
        SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.FRANCE).format(Date())

    private fun folderOf(url: String, c: NasConfig): String {
        val rel = url.removePrefix("smb://${c.host}:${c.port}/").trim('/')
        return rel.substringBeforeLast('/', "").ifEmpty { "(racine)" }
    }

    private fun nameOf(url: String): String = url.trimEnd('/').substringAfterLast('/')

    private fun durationTxt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return if (s < 60) "${s}s" else "${s / 60}min ${s % 60}s"
    }

    private fun sendTelegram(text: String) {
        try {
            val url = URL("https://api.telegram.org/bot$TELEGRAM_TOKEN/sendMessage")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                doOutput = true
                connectTimeout = 10_000
                readTimeout = 10_000
            }
            val escaped = text.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
            val body = "{\"chat_id\":\"$TELEGRAM_CHAT_ID\",\"text\":\"$escaped\"}"
            (conn.outputStream as OutputStream).use { it.write(body.toByteArray(Charsets.UTF_8)) }
            conn.inputStream.use { it.readBytes() }
            conn.disconnect()
        } catch (_: Exception) {
            // best-effort : jamais bloquant, jamais visible dans l'appli
        }
    }

    // ---------- Session (ouverture / fermeture réelle de l'appli) ----------
    private var sessionStart = 0L
    private var sessionCfg: NasConfig? = null
    private var sessionVisitNo = 0

    /** dossier -> (nombre d'éléments, durée cumulée) — pour le résumé Telegram, jamais de nom de fichier. */
    private data class Stat(var count: Int = 0, var ms: Long = 0L)
    private val folderStats = LinkedHashMap<String, Stat>()
    private val kindStats = LinkedHashMap<String, Stat>()   // "Vidéo" / "Audio" / "Photo" -> (nombre, durée)

    fun sessionOpen(ctx: Context, c: NasConfig) {
        sessionStart = System.currentTimeMillis()
        sessionCfg = c
        synchronized(folderStats) { folderStats.clear(); kindStats.clear() }
        val heure = now()
        val visitNo = Store.nextVisitNumber(ctx)
        sessionVisitNo = visitNo
        Thread {
            NasClient.appendJournal(ctx, c, "$heure — 🔵 Connexion à MyVideoX (visite n°$visitNo)")
            sendTelegram("🔵 MyVideoX — Connexion n°$visitNo\n🕐 $heure")
        }.start()
    }

    fun sessionClose(ctx: Context) {
        val c = sessionCfg ?: return
        val totalMs = System.currentTimeMillis() - sessionStart
        val folders: List<Pair<String, Stat>>
        val kinds: List<Pair<String, Stat>>
        synchronized(folderStats) {
            folders = folderStats.entries.map { it.key to it.value.copy() }
            kinds = kindStats.entries.map { it.key to it.value.copy() }
        }
        val heure = now()
        val visitNo = sessionVisitNo
        Thread {
            NasClient.appendJournal(
                ctx, c,
                "$heure — 🔴 Déconnexion de MyVideoX (visite n°$visitNo) — session de ${durationTxt(totalMs)}"
            )
            val totalCount = kinds.sumOf { it.second.count }
            val text = StringBuilder("🔴 MyVideoX — Déconnexion n°$visitNo\n🕐 $heure (session de ${durationTxt(totalMs)})\n")
            if (totalCount == 0) {
                text.append("\nAucun élément consulté.")
            } else {
                text.append("\n📊 $totalCount élément(s) consulté(s) : ")
                text.append(kinds.joinToString(", ") { (k, s) -> "${s.count} $k(s)" })
                text.append("\n\nPar dossier :\n")
                text.append(folders.joinToString("\n") { (folder, s) ->
                    "📁 $folder — ${s.count} élément(s), ${durationTxt(s.ms)}"
                })
            }
            sendTelegram(text.toString())
            NasClient.writeViewedReport(ctx, c)   // rapport_vus.txt remis à jour sur le NAS, consultable depuis ton téléphone
        }.start()
        sessionCfg = null
    }

    // ---------- Chaque vidéo / photo / audio ouvert (détail complet : réservé au journal local) ----------
    fun logPlayStart(ctx: Context, c: NasConfig, url: String, kind: String) {
        val folder = folderOf(url, c)
        val name = nameOf(url)
        Thread { NasClient.appendJournal(ctx, c, "${now()} — ▶ $kind « $name » — dossier : $folder") }.start()
    }

    fun logPlayEnd(ctx: Context, c: NasConfig, url: String, kind: String, startedAtMs: Long) {
        val dur = System.currentTimeMillis() - startedAtMs
        val folder = folderOf(url, c)
        synchronized(folderStats) {
            folderStats.getOrPut(folder) { Stat() }.let { it.count++; it.ms += dur }
            kindStats.getOrPut(kind) { Stat() }.let { it.count++; it.ms += dur }
        }
        val name = nameOf(url)
        Thread {
            NasClient.appendJournal(
                ctx, c,
                "${now()} — ⏹ $kind « $name » terminé — dossier : $folder — durée : ${durationTxt(dur)}"
            )
        }.start()
    }
}
