package com.cedric.myvideox

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import jcifs.CIFSContext
import jcifs.config.PropertyConfiguration
import jcifs.context.BaseContext
import jcifs.smb.NtlmPasswordAuthenticator
import jcifs.smb.SmbFile
import jcifs.smb.SmbFileInputStream
import jcifs.smb.SmbFileOutputStream
import java.io.IOException
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.Collections
import java.util.Properties
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/** Chemin réseau découpé : \\hôte\partage\dossier\sous-dossier */
data class NasPath(val host: String, val share: String, val dir: String) {
    fun display(): String {
        val sb = StringBuilder("\\\\").append(host)
        if (share.isNotEmpty()) sb.append('\\').append(share)
        if (dir.isNotEmpty()) sb.append('\\').append(dir.replace('/', '\\'))
        return sb.toString()
    }
}

data class NasConfig(
    val host: String, val port: Int, val user: String, val password: String,
    val strict: Boolean, val localOnly: Boolean, val path: NasPath
)

enum class Kind { DIR, VIDEO, AUDIO, IMAGE }

data class Entry(val name: String, val url: String, val kind: Kind, val size: Long)

/** Le téléphone n'est pas sur le Wi-Fi de la maison. */
class NotAtHomeException(msg: String) : Exception(msg)

object NasClient {

    private val videoExt = setOf("mp4", "m4v", "mov", "3gp", "mkv", "webm", "avi", "ts", "mpg", "mpeg", "wmv", "flv")
    private val audioExt = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "oga", "opus", "amr", "mka")
    private val imageExt = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")

    fun kindOf(name: String): Kind? {
        val e = name.substringAfterLast('.', "").lowercase()
        return when (e) {
            in videoExt -> Kind.VIDEO
            in audioExt -> Kind.AUDIO
            in imageExt -> Kind.IMAGE
            else -> null
        }
    }

    // ---------- Chemin réseau ----------
    fun parsePath(raw: String): NasPath? {
        var s = raw.trim().replace('\\', '/')
        if (s.startsWith("smb:", ignoreCase = true)) s = s.substring(4)
        val parts = s.split('/').filter { it.isNotBlank() }
        if (parts.isEmpty()) return null
        return NasPath(parts[0].substringBefore(':').trim(), parts.getOrElse(1) { "" }, parts.drop(2).joinToString("/"))
    }

    fun config(ctx: Context): NasConfig? {
        val s = Store.settings(ctx)
        val p = parsePath(s.path) ?: return null
        return NasConfig(p.host, s.port, s.user, s.password, s.strict, s.localOnly, p)
    }

    fun rootUrl(c: NasConfig): String = urlOf(c, c.path.share, c.path.dir)

    /** smb://hôte:port/partage/dossier/ (se termine toujours par « / ») */
    fun urlOf(c: NasConfig, share: String, dir: String): String {
        val sb = StringBuilder("smb://${c.host}:${c.port}/")
        if (share.isNotBlank()) {
            sb.append(share.trim('/')).append('/')
            val d = dir.trim('/', '\\').replace('\\', '/')
            if (d.isNotEmpty()) sb.append(d).append('/')
        }
        return sb.toString()
    }

    // ---------- Sécurité : uniquement le réseau local ----------
    fun isPrivateHost(h: String): Boolean {
        val m = Regex("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$").matchEntire(h.trim()) ?: return false
        val a = m.groupValues.drop(1).map { it.toInt() }
        if (a.any { it > 255 }) return false
        return a[0] == 10 || (a[0] == 192 && a[1] == 168) || (a[0] == 172 && a[1] in 16..31)
    }

    private fun ipToInt(ip: String): Int {
        val p = ip.trim().split(".").map { it.toInt() }
        return (p[0] shl 24) or (p[1] shl 16) or (p[2] shl 8) or p[3]
    }

    /** Wi-Fi uniquement, aucun VPN, et le NAS doit être dans le même réseau local que le téléphone. */
    private fun assertLocalNetwork(ctx: Context, c: NasConfig) {
        if (!c.localOnly) return
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        var vpn = false
        var sameLan = false
        @Suppress("DEPRECATION")
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) vpn = true
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
                !caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
            ) {
                val lp = cm.getLinkProperties(n) ?: continue
                for (la in lp.linkAddresses) {
                    val a = la.address
                    if (a is Inet4Address) {
                        val mask = if (la.prefixLength == 0) 0 else (-1 shl (32 - la.prefixLength))
                        if ((ipToInt(a.hostAddress!!) and mask) == (ipToInt(c.host) and mask)) sameLan = true
                    }
                }
            }
        }
        if (vpn) throw NotAtHomeException("Un VPN est actif : l'appli ne fonctionne qu'en Wi-Fi local, sans VPN.")
        if (!sameLan) throw NotAtHomeException("Le téléphone n'est pas sur le même réseau Wi-Fi local que le NAS.")
    }

    // ---------- Connexion SMB (jcifs-ng, identique à MyNASx) ----------
    private var cachedKey = ""
    private var cachedCtx: CIFSContext? = null

    @Synchronized
    fun context(ctx: Context, c: NasConfig): CIFSContext {
        require(isPrivateHost(c.host)) {
            "Adresse refusée : ce n'est pas une adresse locale (192.168.x.x, 10.x.x.x ou 172.16 à 31.x.x)."
        }
        assertLocalNetwork(ctx, c)
        val key = "${c.host}|${c.port}|${c.user}|${c.password.hashCode()}|${c.strict}"
        cachedCtx?.let { if (key == cachedKey) return it }
        val p = Properties()
        p.setProperty("jcifs.smb.client.minVersion", if (c.strict) "SMB300" else "SMB1")
        p.setProperty("jcifs.smb.client.maxVersion", "SMB311")
        p.setProperty("jcifs.smb.client.signingEnforced", c.strict.toString())
        p.setProperty("jcifs.smb.client.ipcSigningEnforced", c.strict.toString())
        p.setProperty("jcifs.smb.client.connTimeout", "15000")
        p.setProperty("jcifs.smb.client.responseTimeout", "30000")
        p.setProperty("jcifs.smb.client.soTimeout", "60000")
        val base = BaseContext(PropertyConfiguration(p))
        val out = base.withCredentials(NtlmPasswordAuthenticator(null, c.user.trim(), c.password))
        cachedKey = key
        cachedCtx = out
        return out
    }

    // ---------- Lister ----------
    private fun hidden(n: String) =
        n.startsWith(".") || n.startsWith("@") || n.startsWith("$") || n.startsWith("#") ||
            n.equals("Thumbs.db", true) || n.equals("desktop.ini", true)

    /** Dossiers + fichiers photo / vidéo / audio d'un dossier (le reste est masqué). */
    fun list(ctx: Context, c: NasConfig, dirUrl: String): List<Entry> {
        val base = if (dirUrl.endsWith("/")) dirUrl else "$dirUrl/"
        val out = ArrayList<Entry>()
        for (f in SmbFile(base, context(ctx, c)).listFiles()) {
            val raw = f.name
            val name = raw.trimEnd('/')
            if (name.isEmpty() || hidden(name)) continue
            if (f.isDirectory) {
                out.add(Entry(name, base + name + "/", Kind.DIR, 0L))
            } else {
                val k = kindOf(name) ?: continue
                out.add(Entry(name, base + name, k, f.length()))
            }
        }
        return out.sortedWith(
            compareBy<Entry> { it.kind != Kind.DIR }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.name }
        )
    }

    /** Tous les partages du NAS (sans les partages cachés finissant par $). */
    fun listShares(ctx: Context, c: NasConfig): List<String> =
        SmbFile(urlOf(c, "", ""), context(ctx, c)).listFiles()
            .map { it.name.trimEnd('/') }
            .filter { it.isNotEmpty() && !it.endsWith("$") }
            .sortedBy { it.lowercase() }

    /** Sous-dossiers d'un dossier d'un partage (pour choisir le dossier dans les réglages). */
    fun listDirs(ctx: Context, c: NasConfig, share: String, dir: String): List<String> =
        SmbFile(urlOf(c, share, dir), context(ctx, c)).listFiles()
            .filter { it.isDirectory }
            .map { it.name.trimEnd('/') }
            .filter { it.isNotEmpty() && !hidden(it) }
            .sortedBy { it.lowercase() }

    /** Lit un fichier entier en mémoire (photos). Refuse au-delà de maxBytes. */
    fun readBytes(ctx: Context, c: NasConfig, url: String, maxBytes: Long): ByteArray {
        val f = SmbFile(url, context(ctx, c))
        val len = f.length()
        if (len > maxBytes) throw IOException("Fichier trop volumineux pour être affiché (${humanSize(len)}).")
        return SmbFileInputStream(f).use { it.readBytes() }
    }

    // ---------- Journal des consultations (fichier local sur le NAS, jamais envoyé sur Internet) ----------
    /** Dossier caché DANS le dossier racine configuré dans MyVideoX : invisible dans les listes (le filtre `hidden()` l'exclut déjà). */
    private fun journalDirUrl(c: NasConfig): String {
        val base = if (c.path.dir.isBlank()) ".myvideox_journal" else "${c.path.dir}/.myvideox_journal"
        return urlOf(c, c.path.share, base)
    }

    /** Ajoute une ligne au journal. Ne doit jamais interrompre la lecture : toute erreur est silencieuse. */
    fun appendJournal(ctx: Context, c: NasConfig, line: String) {
        try {
            val dirUrl = journalDirUrl(c)
            val dir = SmbFile(dirUrl, context(ctx, c))
            if (!dir.exists()) dir.mkdirs()
            val f = SmbFile(dirUrl + "journal.txt", context(ctx, c))
            SmbFileOutputStream(f, true).use { it.write((line + "\n").toByteArray(Charsets.UTF_8)) }
        } catch (_: Exception) {
            // best-effort : le journal ne doit jamais faire planter ou bloquer l'appli
        }
    }

    private val journalLineRe = Regex("«\\s*(.+?)\\s*»\\s*—\\s*dossier\\s*:\\s*(.+)$")

    /**
     * Ensemble "dossier/nom" de tout ce qui a déjà été ouvert au moins une fois,
     * d'après le journal local (jamais transmis sur Internet — lecture admin uniquement).
     */
    fun readViewedSet(ctx: Context, c: NasConfig): Set<String> {
        val out = HashSet<String>()
        try {
            val f = SmbFile(journalDirUrl(c) + "journal.txt", context(ctx, c))
            if (!f.exists()) return out
            val text = SmbFileInputStream(f).use { it.readBytes() }.toString(Charsets.UTF_8)
            for (line in text.lineSequence()) {
                if ("▶" !in line) continue
                val m = journalLineRe.find(line) ?: continue
                val name = m.groupValues[1]
                val folder = m.groupValues[2].trim()
                out.add("$folder/$name")
            }
        } catch (_: Exception) {
            // si le journal est illisible, on affichera simplement « jamais vu » partout
        }
        return out
    }

    /** Parcourt récursivement tous les sous-dossiers à partir de dirUrl et renvoie les fichiers (photo/vidéo/audio) uniquement. */
    fun listRecursive(ctx: Context, c: NasConfig, dirUrl: String, maxDepth: Int = 12): List<Entry> {
        val out = ArrayList<Entry>()
        fun walk(url: String, depth: Int) {
            if (depth > maxDepth) return
            val entries = try { list(ctx, c, url) } catch (_: Exception) { return }
            for (e in entries) {
                if (e.kind == Kind.DIR) walk(e.url, depth + 1) else out.add(e)
            }
        }
        walk(dirUrl, 0)
        return out
    }

    /**
     * Régénère un rapport texte « vu / jamais vu » directement sur le NAS (dossier caché, aucun
     * envoi Internet). Lis-le depuis TON téléphone, avec n'importe quelle appli de fichiers SMB
     * pointée sur ton NAS — jamais besoin de toucher au téléphone qui fait tourner MyVideoX.
     * Mis à jour automatiquement à chaque déconnexion de l'appli.
     */
    fun writeViewedReport(ctx: Context, c: NasConfig) {
        try {
            val viewed = readViewedSet(ctx, c)
            val files = listRecursive(ctx, c, rootUrl(c))
            val lines = files.map { e ->
                val rel = e.url.removePrefix("smb://${c.host}:${c.port}/").trim('/')
                val name = rel.substringAfterLast('/')
                val folder = rel.substringBeforeLast('/', "").ifEmpty { "(racine)" }
                val icon = when (e.kind) { Kind.VIDEO -> "🎬"; Kind.AUDIO -> "🎵"; Kind.IMAGE -> "🖼"; else -> "📄" }
                val seen = viewed.contains("$folder/$name")
                Triple(seen, folder, "${if (seen) "✅" else "⭐ JAMAIS VU"}  $icon  $name")
            }.sortedWith(compareBy({ it.first }, { it.second }))
            val never = lines.count { !it.first }
            val header = "Rapport MyVideoX — mis à jour automatiquement à chaque déconnexion\n" +
                "${lines.size} élément(s) au total — $never jamais ouvert(s)\n" +
                "=".repeat(50) + "\n\n"
            val body = lines.joinToString("\n") { "[${it.second}] ${it.third}" }
            val dirUrl = journalDirUrl(c)
            val dir = SmbFile(dirUrl, context(ctx, c))
            if (!dir.exists()) dir.mkdirs()
            val f = SmbFile(dirUrl + "rapport_vus.txt", context(ctx, c))
            SmbFileOutputStream(f, false).use { it.write((header + body).toByteArray(Charsets.UTF_8)) }
        } catch (_: Exception) {
            // best-effort : ne doit jamais interrompre quoi que ce soit côté utilisatrice
        }
    }

    // ---------- Trouver le NAS sur le Wi-Fi ----------
    fun scanLan(): List<String> {
        val addrs = Collections.list(NetworkInterface.getNetworkInterfaces())
            .filter { it.isUp }
            .flatMap { nif -> Collections.list(nif.inetAddresses).map { nif.name to it } }
            .filter { (_, a) -> a is Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress }
        val mine = (addrs.firstOrNull { it.first.startsWith("wlan") } ?: addrs.firstOrNull())?.second
            ?: return emptyList()
        val prefix = mine.hostAddress!!.substringBeforeLast('.')
        val found = Collections.synchronizedList(ArrayList<String>())
        val pool = Executors.newFixedThreadPool(64)
        try {
            pool.invokeAll((1..254).map { n ->
                Callable {
                    val ip = "$prefix.$n"
                    try {
                        Socket().use { it.connect(InetSocketAddress(ip, 445), 500) }
                        found.add(ip)
                    } catch (_: Exception) {
                    }
                }
            })
        } finally {
            pool.shutdown()
        }
        return found.sortedBy { it.substringAfterLast('.').toInt() }
    }

    // ---------- Messages d'erreur lisibles ----------
    fun humanSize(b: Long): String = when {
        b >= 1_000_000_000L -> "%.2f Go".format(b / 1_000_000_000.0)
        b >= 1_000_000L -> "%.0f Mo".format(b / 1_000_000.0)
        b >= 1_000L -> "%.0f Ko".format(b / 1_000.0)
        else -> "$b o"
    }

    fun friendly(e: Throwable): String {
        val all = generateSequence(e) { it.cause }.joinToString(" | ") {
            "${it.javaClass.simpleName} ${it.message ?: ""}"
        }
        return when {
            "NotAtHomeException" in all ->
                "🔒 " + all.substringAfter("NotAtHomeException ").substringBefore(" | ")
            "Adresse refusée" in all ->
                "🔒 " + all.substringAfter("IllegalArgumentException ").substringBefore(" | ")
            "network name cannot be found" in all || "BAD_NETWORK_NAME" in all ->
                "Partage introuvable sur le NAS. Vérifie le nom du partage dans les réglages (⚙)."
            "SmbAuthException" in all || "Logon failure" in all || "unknown user name" in all ||
                "LOGON_FAILURE" in all || "WRONG_PASSWORD" in all ->
                "Utilisateur ou mot de passe refusé par le NAS (⚙ Réglages)."
            "Access is denied" in all || "ACCESS_DENIED" in all ->
                "Accès refusé : ce compte n'a pas le droit de lire ce dossier (à régler dans ADM)."
            "cannot find the path" in all || "cannot find the file" in all ||
                "OBJECT_PATH_NOT_FOUND" in all || "OBJECT_NAME_NOT_FOUND" in all ->
                "Dossier introuvable sur le NAS."
            "UnknownHost" in all ->
                "Adresse du NAS introuvable."
            "ConnectException" in all || "SocketTimeout" in all || "Timeout" in all ||
                "timed out" in all || "refused" in all || "Unreachable" in all || "NoRouteToHost" in all ->
                "NAS injoignable : Wi-Fi allumé à la maison ? NAS allumé ? bonne adresse ?"
            "negotiate" in all || "EOFException" in all || "dialect" in all || "Unsupported" in all ->
                "Le NAS refuse la discussion SMB sécurisée. Dans ⚙ Réglages, désactive le « Mode strict », puis réessaie.\n" + details(e)
            else -> e.message?.takeIf { it.isNotBlank() && e is IOException } ?: ("Erreur technique :\n" + details(e))
        }
    }

    fun details(e: Throwable): String =
        generateSequence(e) { it.cause }.take(6).joinToString("\n") {
            "• ${it.javaClass.name}: ${(it.message ?: "").take(300)}"
        }
}
