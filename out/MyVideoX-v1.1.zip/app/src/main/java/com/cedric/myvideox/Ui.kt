package com.cedric.myvideox

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView

object Ui {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun label(c: Context, t: String) = TextView(c).apply {
        text = t
        setTextColor(Color.parseColor("#FF8D99A3"))
        setPadding(0, dp(c, 12), 0, 0)
    }

    fun field(c: Context, hint: String, type: Int = InputType.TYPE_CLASS_TEXT, value: String = "") =
        EditText(c).apply {
            this.hint = hint
            setSingleLine()          // AVANT inputType, sinon il écrase le masquage du mot de passe
            inputType = type
            if (type and InputType.TYPE_TEXT_VARIATION_PASSWORD != 0) {
                transformationMethod = android.text.method.PasswordTransformationMethod.getInstance()
                importantForAutofill = android.view.View.IMPORTANT_FOR_AUTOFILL_NO
            }
            setText(value)
        }

    fun button(c: Context, t: String, onClick: () -> Unit) = Button(c).apply {
        text = t
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    fun switch(c: Context, t: String, checked: Boolean) = Switch(c).apply {
        text = t
        isChecked = checked
        setPadding(0, dp(c, 8), 0, dp(c, 8))
    }

    /** Pop-up au centre de l'écran, texte sélectionnable (pour copier une erreur). */
    fun popup(a: Activity, title: String, msg: String) {
        if (a.isFinishing) return
        val d = AlertDialog.Builder(a).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show()
        d.findViewById<TextView>(android.R.id.message)?.setTextIsSelectable(true)
    }

    fun choose(a: Activity, title: String, items: List<String>, onPick: (Int) -> Unit) {
        if (a.isFinishing) return
        AlertDialog.Builder(a).setTitle(title)
            .setItems(items.toTypedArray()) { _, i -> onPick(i) }
            .setNegativeButton("Annuler", null)
            .show()
    }
}
