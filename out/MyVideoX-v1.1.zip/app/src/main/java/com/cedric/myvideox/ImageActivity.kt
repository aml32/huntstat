package com.cedric.myvideox

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Bundle
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayInputStream
import java.io.IOException
import kotlin.math.abs
import kotlin.math.max

/** Visionneuse de photos : zoom (pincer / double-tap), glisser pour passer à la photo suivante. */
class ImageActivity : BaseActivity() {

    private lateinit var img: ZoomImageView
    private lateinit var info: TextView
    private var urls: List<String> = emptyList()
    private var names: List<String> = emptyList()
    private var index = 0
    private var gen = 0
    private var curUrl: String? = null
    private var curStart = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        urls = intent.getStringArrayListExtra("urls") ?: arrayListOf()
        names = intent.getStringArrayListExtra("names") ?: arrayListOf()
        index = intent.getIntExtra("index", 0)
        if (urls.isEmpty() || urls.size != names.size) { finish(); return }

        img = ZoomImageView(this).apply { onSwipe = { d -> go(d) } }
        info = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        }
        fun arrow(t: String, d: Int) = TextView(this).apply {
            text = t
            textSize = 28f
            gravity = Gravity.CENTER
            minimumWidth = Ui.dp(context, 56)
            minimumHeight = Ui.dp(context, 48)
            setOnClickListener { go(d) }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xAA000000.toInt())
            addView(arrow("◀", -1))
            addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(arrow("▶", 1))
        }
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        root.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)
        show(index.coerceIn(0, urls.size - 1))
    }

    private fun go(d: Int) {
        val n = index + d
        if (n in urls.indices) show(n)
    }

    private fun endPhotoLog() {
        val c = NasClient.config(this)
        val u = curUrl
        if (c != null && u != null) Journal.logPlayEnd(applicationContext, c, u, "Photo", curStart)
        curUrl = null
    }

    private fun show(i: Int) {
        endPhotoLog()
        index = i
        val g = ++gen
        info.text = "⏳ ${names[i]}"
        val cfg = NasClient.config(this)
        if (cfg == null) { finish(); return }
        curUrl = urls[i]
        curStart = System.currentTimeMillis()
        Journal.logPlayStart(applicationContext, cfg, urls[i], "Photo")
        Thread {
            try {
                val bytes = NasClient.readBytes(applicationContext, cfg, urls[i], 80_000_000L)
                val bmp = decode(bytes)
                runOnUiThread {
                    if (g == gen) {
                        img.setImageBitmap(bmp)
                        img.reset()
                        info.text = "${i + 1} / ${urls.size} — ${names[i]}"
                    }
                }
            } catch (e: Throwable) {
                val m = if (e is OutOfMemoryError) "Photo trop grande pour la mémoire du téléphone." else NasClient.friendly(e)
                runOnUiThread {
                    if (g == gen) {
                        info.text = "❌ ${names[i]}"
                        Ui.popup(this, "Photo illisible", m)
                    }
                }
            }
        }.start()
    }

    override fun onStop() {
        super.onStop()
        endPhotoLog()
    }

    private fun decode(b: ByteArray): Bitmap {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > 3000) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = BitmapFactory.decodeByteArray(b, 0, b.size, o2)
            ?: throw IOException("Image illisible (format non pris en charge par ce téléphone ?)")
        val orient = try {
            ExifInterface(ByteArrayInputStream(b))
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } catch (_: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val m = Matrix()
        when (orient) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return bmp
        }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }
}

/** ImageView avec zoom (pincer, double-tap), déplacement, et glissement gauche/droite pour changer de photo. */
class ZoomImageView(c: Context) : ImageView(c) {
    var onSwipe: ((Int) -> Unit)? = null
    private var sc = 1f
    private var tx = 0f
    private var ty = 0f

    private val scaler = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            sc = (sc * detector.scaleFactor).coerceIn(1f, 6f)
            clamp(); applyT()
            return true
        }
    })

    private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (sc > 1f) { sc = 1f; tx = 0f; ty = 0f } else sc = 2.5f
            clamp(); applyT()
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (sc > 1f) {
                tx -= distanceX; ty -= distanceY
                clamp(); applyT()
            }
            return true
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            if (sc <= 1.01f && abs(velocityX) > 900f && abs(velocityX) > abs(velocityY)) {
                onSwipe?.invoke(if (velocityX < 0) 1 else -1)
                return true
            }
            return false
        }
    })

    init { scaleType = ScaleType.FIT_CENTER }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        scaler.onTouchEvent(ev)
        if (!scaler.isInProgress) gd.onTouchEvent(ev)
        return true
    }

    fun reset() { sc = 1f; tx = 0f; ty = 0f; applyT() }

    private fun clamp() {
        val mx = (sc - 1f) * width / 2f
        val my = (sc - 1f) * height / 2f
        tx = tx.coerceIn(-mx, mx)
        ty = ty.coerceIn(-my, my)
    }

    private fun applyT() {
        scaleX = sc; scaleY = sc
        translationX = tx; translationY = ty
    }
}
