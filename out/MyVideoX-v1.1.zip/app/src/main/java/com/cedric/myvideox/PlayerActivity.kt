package com.cedric.myvideox

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

/** Lecteur vidéo / audio : lit directement sur le NAS, avec avance rapide, suivant / précédent. */
class PlayerActivity : BaseActivity() {

    private var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private lateinit var titleV: TextView
    private var urls: List<String> = emptyList()
    private var names: List<String> = emptyList()
    private var index = 0
    private var pos = 0L
    private var playing = true
    private var audio = false
    private var cfg: NasConfig? = null
    private var curUrl: String? = null
    private var curStart = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        urls = intent.getStringArrayListExtra("urls") ?: arrayListOf()
        names = intent.getStringArrayListExtra("names") ?: arrayListOf()
        index = intent.getIntExtra("index", 0)
        audio = intent.getBooleanExtra("audio", false)
        if (urls.isEmpty() || urls.size != names.size) { finish(); return }
        cfg = NasClient.config(this)

        view = PlayerView(this).apply {
            setShowNextButton(true)
            setShowPreviousButton(true)
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            if (audio) {
                controllerShowTimeoutMs = 0
                controllerHideOnTouch = false
            } else {
                controllerShowTimeoutMs = 3500
            }
        }
        titleV = TextView(this).apply {
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(Ui.dp(context, 24), Ui.dp(context, 24), Ui.dp(context, 24), Ui.dp(context, 24))
            visibility = if (audio) android.view.View.VISIBLE else android.view.View.GONE
        }
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(titleV, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        setContentView(root)

        if (!audio) {
            // Vidéo : l'écran ne doit jamais se mettre en veille pendant la lecture.
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            view.keepScreenOn = true
            val ctl = WindowCompat.getInsetsController(window, window.decorView)
            ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onStart() {
        super.onStart()
        if (urls.isEmpty()) return
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(SmbDataSource.factory(this)))
            .build()
        val items = urls.indices.map { i ->
            MediaItem.Builder()
                .setUri(SmbDataSource.uriFor(urls[i], names[i]))
                .setMediaId(urls[i])
                .setMediaMetadata(MediaMetadata.Builder().setTitle(names[i]).build())
                .build()
        }
        // L'écouteur doit être posé AVANT setMediaItems() : sinon la transition vers le tout premier
        // élément (déclenchée par setMediaItems lui-même) n'est reçue par personne, et rien n'est journalisé
        // pour une vidéo unique regardée brièvement (bug repéré le 21/10).
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val msg = when (error.errorCode) {
                    PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
                    PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
                    PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
                    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
                    PlaybackException.ERROR_CODE_DECODING_FAILED ->
                        "Ce format n'est pas lu par le téléphone (ou le fichier est abîmé)."
                    else -> NasClient.friendly(error)
                }
                Ui.popup(this@PlayerActivity, "Lecture impossible", msg)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                titleV.text = "🎵\n" + (mediaItem?.mediaMetadata?.title ?: "")
                endCurrentLog()
                startCurrentLog(mediaItem?.mediaId)
            }
        })
        p.setMediaItems(items, index.coerceIn(0, items.size - 1), pos)
        view.player = p
        p.prepare()
        p.playWhenReady = playing
        player = p
    }

    private fun startCurrentLog(url: String?) {
        val c = cfg
        if (c != null && url != null) {
            curUrl = url
            curStart = System.currentTimeMillis()
            Journal.logPlayStart(applicationContext, c, url, if (audio) "Audio" else "Vidéo")
        }
    }

    private fun endCurrentLog() {
        val c = cfg
        val u = curUrl
        if (c != null && u != null) {
            Journal.logPlayEnd(applicationContext, c, u, if (audio) "Audio" else "Vidéo", curStart)
        }
        curUrl = null
    }

    override fun onStop() {
        super.onStop()
        endCurrentLog()
        player?.let {
            index = it.currentMediaItemIndex
            pos = it.currentPosition
            playing = it.playWhenReady
            view.player = null
            it.release()
        }
        player = null
    }
}
