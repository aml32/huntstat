package com.cedric.myvideox

import android.content.Context
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import jcifs.smb.SmbFile
import jcifs.smb.SmbFileInputStream
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream

/**
 * Lit une vidéo / un son directement sur le NAS (sans rien copier sur le téléphone), avec avance rapide.
 * L'adresse est de la forme  myvideox-nas://x/NomDuFichier?u=smb://192.168.1.100:445/...
 */
class SmbDataSource(private val appCtx: Context) : BaseDataSource(true) {

    companion object {
        fun uriFor(smbUrl: String, name: String): Uri =
            Uri.Builder().scheme("myvideox-nas").authority("x").appendPath(name)
                .appendQueryParameter("u", smbUrl).build()

        fun factory(ctx: Context) = DataSource.Factory { SmbDataSource(ctx.applicationContext) }
    }

    private var uri: Uri? = null
    private var stream: InputStream? = null
    private var remaining = 0L
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        uri = dataSpec.uri
        transferInitializing(dataSpec)
        val cfg = NasClient.config(appCtx) ?: throw IOException("Aucun chemin réseau configuré")
        val url = dataSpec.uri.getQueryParameter("u") ?: throw IOException("Adresse vide")
        // Sécurité : on ne lit que sur le NAS configuré
        if (!url.startsWith("smb://${cfg.host}:${cfg.port}/")) throw IOException("Adresse refusée")
        val file = SmbFile(url, NasClient.context(appCtx, cfg))
        val length = file.length()
        val pos = dataSpec.position
        if (pos > length) throw IOException("Position de lecture hors du fichier")
        val raw = SmbFileInputStream(file)
        var left = pos
        while (left > 0) {
            val s = raw.skip(left)
            if (s <= 0) break
            left -= s
        }
        stream = BufferedInputStream(raw, 256 * 1024)
        remaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) minOf(dataSpec.length, length - pos) else length - pos
        opened = true
        transferStarted(dataSpec)
        return remaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining == 0L) return C.RESULT_END_OF_INPUT
        val n = stream!!.read(buffer, offset, minOf(remaining, length.toLong()).toInt())
        if (n < 0) return C.RESULT_END_OF_INPUT
        remaining -= n
        bytesTransferred(n)
        return n
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        uri = null
        try {
            stream?.close()
        } catch (_: Exception) {
        } finally {
            stream = null
            if (opened) {
                opened = false
                transferEnded()
            }
        }
    }
}
