package com.cedric.myvideox

import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Réglages (protégés par le code d'accès) : chemin réseau du NAS, identifiants, sécurité. */
class SettingsActivity : BaseActivity() {

    private lateinit var pathF: EditText
    private lateinit var userF: EditText
    private lateinit var passF: EditText
    private lateinit var pinF: EditText
    private lateinit var portF: EditText
    private lateinit var lockSw: Switch
    private lateinit var secureSw: Switch
    private lateinit var localSw: Switch
    private lateinit var strictSw: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val s = Store.settings(this)
        val pad = Ui.dp(this, 16)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun title(t: String) = TextView(this).apply {
            text = t
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, Ui.dp(this@SettingsActivity, 24), 0, 0)
        }
        fun note(t: String) = TextView(this).apply {
            text = t
            textSize = 12f
            setTextColor(0xFF8D99A3.toInt())
        }

        col.addView(title("📂 Chemin réseau du NAS"))
        pathF = Ui.field(this, "\\\\192.168.1.100\\Video\\Famille", InputType.TYPE_TEXT_VARIATION_URI, s.path)
        col.addView(Ui.label(this, "Dossier qui contient tes photos et vidéos"))
        col.addView(pathF)
        col.addView(note("Écris-le comme sur un PC : \\\\adresse-du-NAS\\partage\\dossier. Utilise l'adresse (192.168.x.x), pas le nom."))
        col.addView(Ui.button(this, "🔍 Chercher le NAS sur le Wi-Fi") { scan() })
        col.addView(Ui.button(this, "📁 Choisir le dossier en parcourant le NAS") { browse() })

        col.addView(title("🔑 Identifiants du NAS"))
        userF = Ui.field(this, "Utilisateur du NAS", value = s.user)
        passF = Ui.field(
            this, if (s.password.isEmpty()) "Mot de passe" else "•••••••• (vide = inchangé)",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD, ""
        )
        col.addView(Ui.label(this, "Utilisateur")); col.addView(userF)
        col.addView(Ui.label(this, "Mot de passe")); col.addView(passF)
        col.addView(Ui.button(this, "🧪 Tester la connexion") { test() })

        col.addView(title("🔒 Sécurité"))
        pinF = Ui.field(
            this, if (Store.hasPin(this)) "•••• (vide = inchangé)" else "Choisis un code de 4 à 8 chiffres",
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD, ""
        )
        col.addView(Ui.label(this, "Code d'accès (4 à 8 chiffres) — demandé pour ouvrir ces réglages"))
        col.addView(pinF)
        lockSw = Ui.switch(this, "Demander aussi le code à l'ouverture de l'appli", s.lockOnOpen)
        secureSw = Ui.switch(this, "Masquer l'écran dans les captures et applis récentes", s.secure)
        localSw = Ui.switch(this, "Réseau de la maison uniquement (Wi-Fi local, jamais de VPN)", s.localOnly)
        strictSw = Ui.switch(this, "Mode strict : SMB 3 + signature obligatoires", s.strict)
        col.addView(lockSw); col.addView(secureSw); col.addView(localSw); col.addView(strictSw)
        portF = Ui.field(this, "445", InputType.TYPE_CLASS_NUMBER, s.port.toString())
        col.addView(Ui.label(this, "Port SMB (laisse 445 — le 5001 est la page web du NAS)")); col.addView(portF)
        col.addView(note(
            "Aucune connexion vers Internet : l'appli ne parle qu'au NAS de la maison, et seulement sur le Wi-Fi de la maison. " +
                "Le journal des consultations reste lui aussi entièrement sur le NAS (dossier .myvideox_journal).\n" +
                "Code oublié : Android > Paramètres > Applis > MyVideoX > Stockage > Effacer les données (il faudra tout ressaisir)."
        ))

        col.addView(Ui.button(this, "💾 Enregistrer") { if (save()) { toast("Enregistré"); finish() } })
        setContentView(ScrollView(this).apply { addView(col) })
    }


    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    /** Travail réseau hors de l'écran ; erreur affichée dans un pop-up. */
    private fun <T> bg(label: String, work: () -> T, done: (T) -> Unit) {
        toast("⏳ $label")
        Thread {
            try {
                val r = work()
                runOnUiThread { done(r) }
            } catch (e: Exception) {
                val m = NasClient.friendly(e)
                runOnUiThread { Ui.popup(this, "Erreur", m) }
            }
        }.start()
    }

    /** Réglages tels qu'ils sont tapés à l'écran (pour tester / parcourir avant d'enregistrer). */
    private fun typedConfig(): NasConfig? {
        val p = NasClient.parsePath(pathF.text.toString())
        if (p == null) {
            Ui.popup(this, "Chemin réseau manquant", "Indique d'abord le chemin, par exemple :\n\\\\192.168.1.100\\Video\\Famille\n\nOu utilise « Chercher le NAS ».")
            return null
        }
        if (!NasClient.isPrivateHost(p.host)) {
            Ui.popup(
                this, "Adresse refusée",
                "Par sécurité, seule une adresse locale est acceptée (192.168.x.x, 10.x.x.x ou 172.16 à 31.x.x). Remplace le nom du NAS par son adresse."
            )
            return null
        }
        val old = Store.settings(this)
        return NasConfig(
            p.host, portF.text.toString().trim().toIntOrNull() ?: 445, userF.text.toString().trim(),
            passF.text.toString().ifEmpty { old.password }, strictSw.isChecked, localSw.isChecked, p
        )
    }

    private fun scan() {
        bg("Recherche du NAS sur le Wi-Fi… (quelques secondes)", { NasClient.scanLan() }) { ips ->
            if (ips.isEmpty()) {
                Ui.popup(this, "Aucun NAS trouvé", "Le téléphone est-il en Wi-Fi sur le même réseau que le NAS ?")
            } else {
                Ui.choose(this, "Appareils trouvés (ton NAS ?)", ips) { i ->
                    val old = NasClient.parsePath(pathF.text.toString())
                    pathF.setText(NasPath(ips[i], old?.share ?: "", old?.dir ?: "").display())
                }
            }
        }
    }

    private fun test() {
        val c = typedConfig() ?: return
        bg("Test de connexion…", { NasClient.list(applicationContext, c, NasClient.rootUrl(c)) }) { l ->
            Ui.popup(
                this, "Connexion réussie ✅",
                "${c.path.display()}\n\n📁 ${l.count { it.kind == Kind.DIR }} dossier(s)\n🖼 ${l.count { it.kind == Kind.IMAGE }} photo(s)\n" +
                    "🎬 ${l.count { it.kind == Kind.VIDEO }} vidéo(s)\n🎵 ${l.count { it.kind == Kind.AUDIO }} son(s)"
            )
        }
    }

    // ---------- Parcourir le NAS pour choisir le dossier ----------
    private fun browse() {
        val c = typedConfig() ?: return
        step(c, c.path.share, c.path.dir)
    }

    private fun step(c: NasConfig, share: String, dir: String) {
        bg(
            "Lecture du NAS…",
            {
                if (share.isEmpty()) NasClient.listShares(applicationContext, c)
                else NasClient.listDirs(applicationContext, c, share, dir)
            }
        ) { names ->
            val here = NasPath(c.host, share, dir)
            val labels = ArrayList<String>()
            if (share.isNotEmpty()) {
                labels.add("✅ Choisir CE dossier")
                labels.add("⬆ Dossier parent")
            }
            names.forEach { labels.add("📁 $it") }
            if (names.isEmpty()) labels.add("(aucun sous-dossier)")
            val offset = if (share.isNotEmpty()) 2 else 0
            AlertDialog.Builder(this)
                .setTitle(here.display())
                .setItems(labels.toTypedArray()) { _, i ->
                    when {
                        share.isNotEmpty() && i == 0 -> pathF.setText(here.display())
                        share.isNotEmpty() && i == 1 ->
                            if (dir.isEmpty()) step(c, "", "") else step(c, share, dir.substringBeforeLast('/', ""))
                        i - offset in names.indices -> {
                            val n = names[i - offset]
                            if (share.isEmpty()) step(c, n, "") else step(c, share, if (dir.isEmpty()) n else "$dir/$n")
                        }
                    }
                }
                .setNegativeButton("Annuler", null)
                .show()
        }
    }

    private fun save(): Boolean {
        val c = typedConfig() ?: return false
        val pin = pinF.text.toString().trim()
        if (pin.isEmpty() && !Store.hasPin(this)) {
            Ui.popup(this, "Code d'accès nécessaire", "Choisis un code de 4 à 8 chiffres : il protège ces réglages.")
            return false
        }
        if (pin.isNotEmpty()) {
            if (pin.length !in 4..8) {
                Ui.popup(this, "Code trop court ou trop long", "Le code doit faire entre 4 et 8 chiffres.")
                return false
            }
            Store.setPin(this, pin)
        }
        Store.save(
            this,
            Settings(
                path = c.path.display(), port = c.port, user = c.user, password = c.password,
                strict = c.strict, localOnly = c.localOnly, secure = secureSw.isChecked, lockOnOpen = lockSw.isChecked
            )
        )
        return true
    }
}
