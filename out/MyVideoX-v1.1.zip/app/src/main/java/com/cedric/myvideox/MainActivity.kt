package com.cedric.myvideox

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Écran d'accueil : s'ouvre directement sur le dossier du NAS enregistré dans les réglages (⚙). */
class MainActivity : BaseActivity() {

    private lateinit var content: LinearLayout
    private lateinit var backV: TextView
    private lateinit var titleV: TextView
    private lateinit var pathV: TextView
    private lateinit var listV: ListView
    private lateinit var msgBox: LinearLayout
    private lateinit var msgV: TextView
    private lateinit var retryB: Button
    private lateinit var statusV: TextView

    private val stack = ArrayList<String>()      // adresses des dossiers ouverts (le 1er = dossier enregistré)
    private var items: List<Entry> = emptyList()
    private var cfg: NasConfig? = null
    private var loadedStamp = -1L
    private var gen = 0
    private var autoOpened = false
    private var fromLink = false   // ouverte par la tuile du site : le code d'accès est toujours demandé

    private val bar = Color.parseColor("#FF1B2026")
    private val muted = Color.parseColor("#FF8D99A3")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fromLink = isLink(intent)
        val c = this
        content = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }

        // --- barre du haut ---
        val top = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(bar)
            setPadding(Ui.dp(c, 4), Ui.dp(c, 4), Ui.dp(c, 4), Ui.dp(c, 4))
        }
        fun iconBtn(t: String, onClick: () -> Unit) = TextView(c).apply {
            text = t
            textSize = 24f
            gravity = Gravity.CENTER
            minimumWidth = Ui.dp(c, 48)
            minimumHeight = Ui.dp(c, 48)
            setOnClickListener { onClick() }
        }
        backV = iconBtn("⬅") { goUp() }
        titleV = TextView(c).apply {
            textSize = 19f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        top.addView(backV)
        top.addView(titleV, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(iconBtn("🔄") { reload() })
        top.addView(iconBtn("⚙") { openSettings() })
        content.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        pathV = TextView(c).apply {
            textSize = 12f
            setTextColor(muted)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            setPadding(Ui.dp(c, 16), Ui.dp(c, 6), Ui.dp(c, 16), Ui.dp(c, 6))
        }
        content.addView(pathV)

        // --- liste ---
        listV = ListView(c).apply {
            divider = null
            adapter = Adapter()
            setOnItemClickListener { _, _, pos, _ -> onItem(items[pos]) }
        }
        val frame = android.widget.FrameLayout(c)
        frame.addView(listV, android.widget.FrameLayout.LayoutParams(-1, -1))
        msgV = TextView(c).apply {
            textSize = 16f
            gravity = Gravity.CENTER
        }
        retryB = Ui.button(c, "Réessayer") { reload() }
        msgBox = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(Ui.dp(c, 24), Ui.dp(c, 24), Ui.dp(c, 24), Ui.dp(c, 24))
            visibility = View.GONE
            addView(msgV)
            addView(retryB)
        }
        frame.addView(msgBox, android.widget.FrameLayout.LayoutParams(-1, -1))
        content.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // --- statut toujours visible en bas ---
        statusV = TextView(c).apply {
            textSize = 13f
            setTextColor(muted)
            setBackgroundColor(bar)
            setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10))
            maxLines = 3
        }
        content.addView(statusV, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(content)
    }

    private fun isLink(i: Intent?): Boolean =
        i != null && i.action == Intent.ACTION_VIEW && i.data?.scheme == "myvideox"

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (isLink(intent)) fromLink = true
    }

    override fun onResume() {
        super.onResume()
        if (locking) return
        val s = Store.settings(this)
        if (Store.hasPin(this) && (fromLink || (s.lockOnOpen && System.currentTimeMillis() - Lock.last > Lock.GRACE_MS))) {
            locking = true
            content.visibility = View.INVISIBLE
            PinGate.ask(this, "MyVideoX verrouillé", {
                locking = false
                fromLink = false
                Lock.touch()
                content.visibility = View.VISIBLE
                ensureConsent { refreshIfConfigChanged() }
            }, {
                locking = false
                finish()
            })
            return
        }
        ensureConsent { refreshIfConfigChanged() }
    }

    /** Demandé une seule fois, pour toujours : explique que les consultations sont enregistrées. */
    private fun ensureConsent(after: () -> Unit) {
        if (Store.hasConsent(this)) { after(); return }
        content.visibility = View.INVISIBLE
        AlertDialog.Builder(this)
            .setTitle("Avant de continuer")
            .setMessage(
                "Les consultations dans cette application (dossier ouvert, date, heure et durée) sont enregistrées.\n\n" +
                    "En continuant, tu acceptes ces conditions d'utilisation."
            )
            .setCancelable(false)
            .setPositiveButton("J'ai compris, continuer") { _, _ ->
                Store.setConsent(this)
                AppVisibility.tryOpen(this)
                content.visibility = View.VISIBLE
                after()
            }
            .show()
    }

    private fun refreshIfConfigChanged() {
        val st = Store.stamp(this)
        if (st == loadedStamp) return
        loadedStamp = st
        stack.clear()
        cfg = NasClient.config(this)
        val c = cfg
        if (c == null) {
            items = emptyList()
            (listV.adapter as BaseAdapter).notifyDataSetChanged()
            titleV.text = "MyVideoX"
            pathV.text = ""
            backV.visibility = View.INVISIBLE
            showMessage("Bienvenue !\nIndique d'abord le chemin réseau de ton NAS dans les réglages ⚙.", "⚙ Ouvrir les réglages") { openSettings() }
            setStatus("Aucun chemin réseau enregistré.")
            if (!autoOpened) {
                autoOpened = true
                startActivity(Intent(this, SettingsActivity::class.java))
            }
            return
        }
        stack.add(NasClient.rootUrl(c))
        load()
    }

    private fun reload() {
        if (cfg == null) { loadedStamp = -1L; refreshIfConfigChanged() } else load()
    }

    private fun openSettings() {
        val go = { startActivity(Intent(this, SettingsActivity::class.java)) }
        if (Store.hasPin(this)) {
            locking = true
            PinGate.ask(this, "Code d'accès", { locking = false; Lock.touch(); go() }, { locking = false })
        } else go()
    }

    private fun goUp() {
        if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            load()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (stack.size > 1) goUp() else super.onBackPressed()
    }

    private fun load() {
        val c = cfg ?: return
        if (stack.isEmpty()) return
        val url = stack.last()
        val g = ++gen
        updateHeader(url)
        msgBox.visibility = View.GONE
        setStatus("⏳ Chargement…")
        Thread {
            try {
                val l = NasClient.list(applicationContext, c, url)
                runOnUiThread { if (g == gen) show(l) }
            } catch (e: Exception) {
                val m = NasClient.friendly(e)
                runOnUiThread { if (g == gen) showError(m) }
            }
        }.start()
    }

    private fun updateHeader(url: String) {
        val c = cfg ?: return
        val rel = url.removePrefix("smb://${c.host}:${c.port}/").trim('/')
        titleV.text = if (rel.isEmpty()) c.host else rel.substringAfterLast('/')
        pathV.text = "\\\\" + c.host + (if (rel.isEmpty()) "" else "\\" + rel.replace('/', '\\'))
        backV.visibility = if (stack.size > 1) View.VISIBLE else View.INVISIBLE
    }

    private fun show(l: List<Entry>) {
        items = l
        (listV.adapter as BaseAdapter).notifyDataSetChanged()
        listV.setSelection(0)
        val dirs = l.count { it.kind == Kind.DIR }
        val ph = l.count { it.kind == Kind.IMAGE }
        val vi = l.count { it.kind == Kind.VIDEO }
        val au = l.count { it.kind == Kind.AUDIO }
        if (l.isEmpty()) {
            showMessage("Dossier vide\n(aucune photo, vidéo ni musique ici)", null) {}
            setStatus("Dossier vide.")
        } else {
            msgBox.visibility = View.GONE
            setStatus("📂 $dirs dossier(s) · 🖼 $ph photo(s) · 🎬 $vi vidéo(s)" + if (au > 0) " · 🎵 $au son(s)" else "")
        }
    }

    private fun showError(m: String) {
        items = emptyList()
        (listV.adapter as BaseAdapter).notifyDataSetChanged()
        showMessage("❌ " + m.lineSequence().first(), "Réessayer") { load() }
        setStatus("❌ " + m.lineSequence().first())
        Ui.popup(this, "Impossible de lire le NAS", m)
    }

    private fun showMessage(text: String, button: String?, action: () -> Unit) {
        msgV.text = text
        if (button == null) retryB.visibility = View.GONE else {
            retryB.visibility = View.VISIBLE
            retryB.text = button
            retryB.setOnClickListener { action() }
        }
        msgBox.visibility = View.VISIBLE
    }

    private fun setStatus(t: String) {
        statusV.text = t
    }

    private fun onItem(e: Entry) {
        if (e.kind == Kind.DIR) {
            stack.add(e.url)
            load()
            return
        }
        val same = items.filter { it.kind == e.kind }
        val i = Intent(
            this, if (e.kind == Kind.IMAGE) ImageActivity::class.java else PlayerActivity::class.java
        )
        i.putStringArrayListExtra("urls", ArrayList(same.map { it.url }))
        i.putStringArrayListExtra("names", ArrayList(same.map { it.name }))
        i.putExtra("index", same.indexOfFirst { it.url == e.url }.coerceAtLeast(0))
        i.putExtra("audio", e.kind == Kind.AUDIO)
        startActivity(i)
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val c = this@MainActivity
            val row: LinearLayout
            val icon: TextView
            val name: TextView
            val sub: TextView
            if (convertView == null) {
                row = LinearLayout(c).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(Ui.dp(c, 16), Ui.dp(c, 12), Ui.dp(c, 16), Ui.dp(c, 12))
                }
                icon = TextView(c).apply { textSize = 26f; gravity = Gravity.CENTER; minimumWidth = Ui.dp(c, 44) }
                val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
                name = TextView(c).apply { textSize = 16f; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
                sub = TextView(c).apply { textSize = 12f; setTextColor(muted) }
                col.addView(name); col.addView(sub)
                row.addView(icon)
                row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                row.tag = arrayOf(icon, name, sub)
            } else {
                row = convertView as LinearLayout
                @Suppress("UNCHECKED_CAST")
                val t = row.tag as Array<TextView>
                icon = t[0]; name = t[1]; sub = t[2]
            }
            val e = items[position]
            icon.text = when (e.kind) { Kind.DIR -> "📁"; Kind.VIDEO -> "🎬"; Kind.AUDIO -> "🎵"; Kind.IMAGE -> "🖼" }
            name.text = e.name
            sub.text = if (e.kind == Kind.DIR) "Dossier" else NasClient.humanSize(e.size)
            return row
        }
    }
}
